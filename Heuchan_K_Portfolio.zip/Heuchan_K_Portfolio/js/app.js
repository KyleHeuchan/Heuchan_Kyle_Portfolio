(function() {
"use strict";
var imageBanner, listItems;
function init() {
imageBanner = document.querySelector("#randomimages");
listItems = document.querySelectorAll ("#galLinks li");
console.log(listItems);
setUpListItems();
}


function setUpListItems() {
	var offSet = 848;
	for (var i=0; i<listItems.length; i++) {
		listItems[i].addEventListener("click", fireMove, false); 
	}
	
	
	function fireMove(e) {
		moveBanner(e.target.parentNode.id);
	}
		
		function moveBanner(howMuch) {
			console.log( + (offSet * howMuch));
			//alert(howMuch);
			TweenMax.to(imageBanner, .7, {right:(offSet*howMuch)});
	}
	}
	window.addEventListener("load", init, false);
})();